window.onload=function(){
    alert("hi");
}

function sayHello(){
            alert("Hello");
}

function saySomething(val){
    if(val == 1){
        alert("hello");
    }else{
        alert("nothing");
    }
}