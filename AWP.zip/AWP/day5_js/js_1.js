console.log("Hello World 2");
//alert("Hello World 3")
function add() {
    var a = parseInt(document.getElementById("num1").value);
    var b = parseInt(document.getElementById("num2").value);
    var x = a + b;
    alert(eval(x));
}

function ev() {
    var e= "";
    var num1 = parseInt(document.getElementById("num1").value);
    var num2 = parseInt(document.getElementById("num2").value);
    var i="";
    if(num1>num2)
    {
        for (i=num2; i <= num1; i++) {
            if (i % 2 == 0) {
                e += i + "  ";
            }
        }
    }
    else
    {
        for ( i=num1 ;i <= num2; i++) {
            if (i % 2 == 0) {
                e += i + "  ";
            }
        }
    }

    document.getElementById("div2").innerHTML = e;
}

function od() {
    var o= "";
    var num1 = parseInt(document.getElementById("num1").value);
    var num2 = parseInt(document.getElementById("num2").value);
    var i="";
    if(num1>num2)
    {
        for (i=num2; i <= num1; i++) {
            if (i % 2 != 0) {
                o += i + "  ";
            }
        }
    }
    else
    {
        for ( i=num1 ;i <= num2; i++) {
            if (i % 2 != 0) {
                o += i + "  ";
            }
        }
    }
    document.getElementById("div2").innerHTML = o;
}

function even() {
    var e = "";
    for (var i = 1; i <= 100; i++) {
        if (i % 2 == 0) {
            e += i + "  ";
        }
    }
    document.getElementById("div2").innerHTML = e;
}

function odd() {
    var o = "";
    for (var i = 1; i <= 100; i++) {
        if (i % 2 != 0) {
            o += i + "  ";
        }
    }
    document.getElementById("div2").innerHTML = o;
}

function arr()
{
    var arr=[];
    var num1 = parseInt(document.getElementById("num1").value);
    var num2 = parseInt(document.getElementById("num2").value);

    var i="";
    if(num1>num2)
    {
        for (i=num2; i <= num1; i++) {
            arr +=[i] + "  ";
        }
    }
    else
    {
        for ( i=num1 ;i <= num2; i++) {
            arr +=[i] + "  ";
        }
    }
    document.getElementById("div2").innerHTML = arr;
}

function sort()
{
    var arr=[33,22,11,55,88,44,66];
    arr.sort();
    //arr.reverse();
  
    document.getElementById("div2").innerHTML = arr;   
}

function dupl()
{
    var arr=[33,22,11,33,88,44,66,66,22,55];
    let res = [];
    arr.sort();
    for(let i=0; i<arr.length-1; i++)
    {
        if(arr[i+1] == arr[i]){
            res.push(arr[i]);
        }
    }
    document.getElementById("div2").innerHTML = res;   
}