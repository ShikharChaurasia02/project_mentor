function validate()
{
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var age = document.getElementById("age").value;
    if(name.length == 0)
    {
        console.log("null hai bhai");
        alert("Name Cannot Be Empty");
    }
    else if(email.length == 0 || !email.includes("@"))
    {
        alert("Enter valid Email");
    }
    else if(age<18)
    {
        alert("Age Must be Greater than 18");
    }
    else{
        var table = document.getElementById("tb2");
        var rowCount = table.rows.length;
        var row = table.insertRow(rowCount);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        
        cell1.innerHTML = name;
        cell2.innerHTML = email;
        cell3.innerHTML = age;
    }
}
