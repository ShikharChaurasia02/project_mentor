function showData()
{
    var i = document.getElementById("div1");
    console.log(i);
}
function hideData()
{
    document.getElementById("div1").innerHTML = "";
}